import React, { useState } from 'react';
import { Clock, Check, ArrowRight, Sparkles, HelpCircle } from 'lucide-react';
import { SERVICES } from '../data/salonData';
import { ServiceItem } from '../types';
import { InteractiveTilt } from './InteractiveTilt';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const [filter, setFilter] = useState<string>('all');

  const filterTabs = [
    { id: 'all', label: 'All Services' },
    { id: 'cut', label: 'Cuts & Blow-Dry' },
    { id: 'colour', label: 'Colour & Balayage' },
    { id: 'care', label: 'Spa & Smoothening' },
    { id: 'occasion', label: 'Bridal & Party' },
  ];

  const filteredServices = SERVICES.filter((service) => {
    if (filter === 'all') return true;
    if (filter === 'cut') return service.id === 'haircuts-styling' || service.id === 'blow-dry';
    if (filter === 'colour') return service.id === 'hair-colour';
    if (filter === 'care') return service.id === 'hair-spa' || service.id === 'keratin-smoothening' || service.id === 'hair-treatments';
    if (filter === 'occasion') return service.id === 'bridal-party' || service.id === 'hair-consultation';
    return true;
  });

  return (
    <section id="services" className="py-24 bg-[#F5F2EB] relative overflow-hidden border-t border-[#EAE3D8]">
      {/* Background Subtle Accents */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#E8DEC8]/25 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#E3D4BC]/25 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-[0.2em] font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            Signature Hair Menu
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-[#141413] tracking-tight">
            Artistry Tailored to Your Signature Silhouette
          </h2>

          <p className="text-sm sm:text-base text-[#6B6862] leading-relaxed">
            Carefully curated hair treatments designed specifically for Indian hair textures, humidity resilience, and radiant health. Individual services are customizable following in-salon consultation.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id)}
                className={`px-4 py-2 rounded-full text-xs font-medium tracking-wider uppercase transition-all duration-300 ${
                  filter === tab.id
                    ? 'bg-[#141413] text-[#FAF8F5] shadow-sm'
                    : 'bg-[#FFFFFF]/80 hover:bg-[#FFFFFF] text-[#6B6862] hover:text-[#141413] border border-[#EAE3D8]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3D Service Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-7">
          {filteredServices.map((service) => (
            <InteractiveTilt
              key={service.id}
              maxTilt={6}
              scale={1.02}
              className="h-full"
            >
              <div className="group h-full flex flex-col justify-between bg-[#FFFFFF] rounded-2xl overflow-hidden border border-[#EAE3D8] hover:border-[#C5A059]/50 shadow-sm hover:shadow-xl transition-all duration-300">
                
                {/* Image Header */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#20201E]">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700"
                    loading="lazy"
                  />
                  
                  {/* Category Pill */}
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-full text-[10px] uppercase tracking-wider font-semibold bg-[#141413]/70 backdrop-blur-md text-[#FAF8F5] border border-white/10">
                      {service.category}
                    </span>
                  </div>

                  {/* Duration Pill */}
                  <div className="absolute bottom-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-medium bg-[#FFFFFF]/90 backdrop-blur-sm text-[#141413] shadow-xs">
                    <Clock className="w-3 h-3 text-[#C5A059]" />
                    <span>{service.duration}</span>
                  </div>

                  {service.popular && (
                    <div className="absolute top-3 right-3">
                      <span className="px-2 py-0.5 rounded-full text-[9px] uppercase tracking-widest font-bold bg-[#C5A059] text-[#141413] shadow-sm">
                        Popular
                      </span>
                    </div>
                  )}
                </div>

                {/* Service Details */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-serif text-xl font-semibold text-[#141413] group-hover:text-[#C5A059] transition-colors leading-snug">
                      {service.title}
                    </h3>
                    <p className="text-xs text-[#7A766F] leading-relaxed line-clamp-3">
                      {service.description}
                    </p>
                  </div>

                  {/* Benefits List */}
                  <div className="space-y-1.5 pt-1 border-t border-[#F5F2EB]">
                    {service.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center gap-2 text-[11px] text-[#55524C]">
                        <Check className="w-3 h-3 text-[#C5A059] shrink-0" />
                        <span className="truncate">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  {/* Pricing & Booking Trigger */}
                  <div className="pt-3 border-t border-[#F0EAE1] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-[#8E8B82] block">
                        Estimated From
                      </span>
                      <span className="font-serif text-lg font-bold text-[#141413]">
                        {service.startingPrice}
                      </span>
                    </div>

                    <button
                      onClick={() => onSelectService(service)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#141413] text-[#FAF8F5] text-xs font-semibold hover:bg-[#C5A059] transition-colors shadow-xs group/btn"
                    >
                      <span>Book</span>
                      <ArrowRight className="w-3 h-3 group-hover/btn:translate-x-0.5 transition-transform" />
                    </button>
                  </div>

                </div>

              </div>
            </InteractiveTilt>
          ))}
        </div>

        {/* Diagnostic Hair Consultation Banner */}
        <div className="mt-14 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#141413] to-[#252522] text-[#FAF8F5] flex flex-col md:flex-row items-center justify-between gap-6 border border-[#C5A059]/30 shadow-xl">
          <div className="space-y-1.5 text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C5A059] font-medium">
              <HelpCircle className="w-3.5 h-3.5" />
              Unsure which ritual is right for you?
            </div>
            <h3 className="font-serif text-xl sm:text-2xl font-normal text-white">
              Complimentary Texture & Color Diagnostics
            </h3>
            <p className="text-xs sm:text-sm text-[#A8A49C] max-w-xl">
              Drop by Stylopia at Jhansi Rani Square, Sitabuldi. Our senior stylists will diagnose your curl pattern, scalp condition, and porosity before recommending treatments.
            </p>
          </div>

          <button
            onClick={() => {
              const consult = SERVICES.find((s) => s.id === 'hair-consultation') || SERVICES[0];
              onSelectService(consult);
            }}
            className="shrink-0 px-6 py-3 rounded-full bg-[#C5A059] hover:bg-[#D4AF37] text-[#141413] text-xs uppercase tracking-wider font-bold transition-all shadow-md hover:scale-105"
          >
            Schedule Consultation
          </button>
        </div>

      </div>
    </section>
  );
};
