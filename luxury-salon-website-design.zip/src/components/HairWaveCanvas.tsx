import React, { useEffect, useRef } from 'react';

export const HairWaveCanvas: React.FC<{ className?: string }> = ({ className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    window.addEventListener('resize', handleResize);

    let step = 0;

    // Organic strand definitions simulating flowing glossy hair ribbons
    const strands = [
      { speed: 0.003, amplitude: 45, frequency: 0.0018, color: 'rgba(197, 160, 89, 0.18)', width: 2.2, phase: 0 },
      { speed: 0.0024, amplitude: 55, frequency: 0.0014, color: 'rgba(212, 175, 55, 0.12)', width: 1.6, phase: 1.8 },
      { speed: 0.0036, amplitude: 35, frequency: 0.0022, color: 'rgba(224, 197, 138, 0.22)', width: 2.8, phase: 3.2 },
      { speed: 0.0018, amplitude: 65, frequency: 0.0011, color: 'rgba(197, 160, 89, 0.08)', width: 3.5, phase: 4.6 },
      { speed: 0.0028, amplitude: 40, frequency: 0.002, color: 'rgba(242, 232, 211, 0.35)', width: 1.2, phase: 2.4 },
    ];

    const render = () => {
      step += 1;
      ctx.clearRect(0, 0, width, height);

      // Render each flowing hair wave
      strands.forEach((strand, idx) => {
        ctx.beginPath();
        ctx.lineWidth = strand.width;
        ctx.strokeStyle = strand.color;
        ctx.lineCap = 'round';

        const yBase = height * 0.45 + idx * 28;

        for (let x = 0; x <= width; x += 6) {
          const y =
            yBase +
            Math.sin(x * strand.frequency + step * strand.speed + strand.phase) * strand.amplitude +
            Math.cos(x * 0.0008 + step * 0.001) * 20;

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={`pointer-events-none absolute inset-0 z-0 opacity-60 ${className}`}
      aria-hidden="true"
    />
  );
};
