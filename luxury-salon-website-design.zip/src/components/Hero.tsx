import React from 'react';
import { ArrowRight, Sparkles, Star, ShieldCheck, Heart, Clock } from 'lucide-react';
import { BUSINESS_INFO } from '../data/salonData';
import { InteractiveTilt } from './InteractiveTilt';
import { HairWaveCanvas } from './HairWaveCanvas';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden bg-[#FAF8F5] pt-6 pb-16 lg:py-20">
      {/* 3D Flowing Hair Ribbon Background Canvas */}
      <HairWaveCanvas />

      {/* Atmospheric Soft Lighting Circles */}
      <div
        className="pointer-events-none absolute -top-32 -left-32 w-96 h-96 rounded-full bg-[#EAD8B5]/30 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full bg-[#E7DAC7]/40 blur-3xl"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Editorial Luxury Headline & Conversion CTA */}
          <div className="lg:col-span-7 flex flex-col justify-center text-left space-y-7">
            
            {/* Studio Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F2ECE1] border border-[#E3D7C5] w-fit shadow-xs">
              <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-ping" />
              <span className="text-xs uppercase tracking-[0.2em] font-medium text-[#4A4742]">
                Nagpur's Premier Hair Studio
              </span>
              <span className="text-[#8E8B82]">·</span>
              <span className="text-xs font-semibold text-[#8C6D28]">Sitabuldi</span>
            </div>

            {/* Headline */}
            <div className="space-y-3">
              <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-[68px] leading-[1.08] font-normal text-[#141413] tracking-tight">
                Beautiful Hair.
                <span className="block italic font-light text-[#C5A059]">
                  Effortless Confidence.
                </span>
              </h1>
              <p className="text-base sm:text-lg md:text-xl text-[#5A5751] font-light max-w-xl leading-relaxed">
                {BUSINESS_INFO.subtitle} Experience bespoke hair artistry, restorative treatments, and luminous color crafted for modern Indian hair.
              </p>
            </div>

            {/* Verified Salon Attributes */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-6 pt-1 text-xs text-[#524F49]">
              <div className="flex items-center gap-1.5 bg-[#FFFFFF]/80 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-[#EAE3D8]">
                <div className="flex text-[#C5A059]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#C5A059]" />
                  ))}
                </div>
                <span className="font-bold text-[#141413]">{BUSINESS_INFO.rating}</span>
                <span className="text-[#8E8B82]">({BUSINESS_INFO.reviewCount} Reviews)</span>
              </div>

              <div className="flex items-center gap-1.5 bg-[#FFFFFF]/80 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-[#EAE3D8]">
                <Heart className="w-3.5 h-3.5 text-[#C5A059]" />
                <span className="font-medium text-[#141413]">{BUSINESS_INFO.businessAttribute}</span>
              </div>

              <div className="flex items-center gap-1.5 bg-[#FFFFFF]/80 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-[#EAE3D8]">
                <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                <span className="font-medium text-[#141413]">Closes 10 PM</span>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onOpenBooking}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-[#141413] text-[#FAF8F5] text-sm font-semibold tracking-wider uppercase overflow-hidden shadow-lg hover:shadow-2xl hover:bg-[#20201D] transition-all duration-300"
              >
                <Sparkles className="w-4 h-4 text-[#C5A059] group-hover:rotate-12 transition-transform duration-300" />
                <span>Book an Appointment</span>
                <ArrowRight className="w-4 h-4 text-[#FAF8F5] group-hover:translate-x-1 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#C5A059]/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              </button>

              <a
                href="#services"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 rounded-full bg-[#FFFFFF]/70 hover:bg-[#FFFFFF] text-[#141413] text-sm font-semibold tracking-wider uppercase border border-[#D9D1C5] hover:border-[#141413] transition-all duration-300"
              >
                <span>Explore Services</span>
              </a>
            </div>

            {/* Direct Phone Assistance */}
            <div className="pt-1 flex items-center gap-2 text-xs text-[#736F68]">
              <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
              <span>Instant Confirmation · Call directly at </span>
              <a
                href={`tel:${BUSINESS_INFO.phoneRaw}`}
                className="font-semibold text-[#141413] hover:text-[#C5A059] underline underline-offset-2 transition-colors"
              >
                {BUSINESS_INFO.phone}
              </a>
            </div>

          </div>

          {/* Right Column: 3D Cinematic Visual Framing Realistic Indian Hair */}
          <div className="lg:col-span-5 flex justify-center items-center">
            <InteractiveTilt
              className="w-full max-w-md lg:max-w-none"
              maxTilt={7}
              scale={1.015}
            >
              <div className="relative rounded-3xl p-3 bg-gradient-to-b from-[#FFFFFF] to-[#EFE8DD] shadow-2xl border border-[#E7DECF]/80">
                {/* Image Container */}
                <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden bg-[#141413]">
                  <img
                    src="/images/hero-stylopia.jpg"
                    alt="Stylopia Hair Studio client with gorgeous glossy dark styled hair"
                    className="w-full h-full object-cover object-top transition-transform duration-700 hover:scale-105"
                    loading="eager"
                  />
                  {/* Subtle Cinematic Vignette */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#141413]/60 via-transparent to-transparent pointer-events-none" />

                  {/* Floating Glass Pill: Salon Signature */}
                  <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl glass-card-dark text-[#FAF8F5] border border-[#C5A059]/30">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-semibold">
                          Signature Blowout & Shine
                        </p>
                        <p className="font-serif text-lg text-white font-medium">
                          Effortless Volume & Gloss
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="inline-block px-2.5 py-1 rounded-full bg-[#C5A059]/20 text-[#E6CA85] text-[11px] font-semibold">
                          Sitabuldi
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3D Floating Badge 1 - Rating */}
                <div className="absolute -top-4 -left-4 sm:-left-6 glass-card p-3 sm:p-4 rounded-2xl shadow-xl border border-[#FFFFFF] flex items-center gap-3 animate-float-slow">
                  <div className="w-10 h-10 rounded-full bg-[#141413] flex items-center justify-center text-[#C5A059] font-bold text-sm shadow-md">
                    ★
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-sm text-[#141413]">{BUSINESS_INFO.rating}</span>
                      <span className="text-xs text-[#736F68]">/ 5.0</span>
                    </div>
                    <p className="text-[11px] text-[#524F49] font-medium">{BUSINESS_INFO.reviewCount} Happy Clients</p>
                  </div>
                </div>

                {/* 3D Floating Badge 2 - Women-Owned */}
                <div className="absolute -bottom-4 -right-4 sm:-right-6 glass-card p-3 rounded-2xl shadow-xl border border-[#FFFFFF] flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-[#F4EFEB] flex items-center justify-center text-[#C5A059]">
                    <Heart className="w-4 h-4 fill-[#C5A059]" />
                  </div>
                  <div className="text-left">
                    <p className="text-[10px] uppercase tracking-wider text-[#736F68]">Proudly</p>
                    <p className="text-xs font-semibold text-[#141413]">Women-Owned</p>
                  </div>
                </div>

              </div>
            </InteractiveTilt>
          </div>

        </div>
      </div>
    </section>
  );
};
