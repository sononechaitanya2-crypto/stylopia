import React from 'react';
import { Heart, Sparkles, MapPin, Clock, Star, ShieldCheck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/salonData';
import { InteractiveTilt } from './InteractiveTilt';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-[#FAF8F5] relative overflow-hidden border-t border-[#EAE3D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Visual Column */}
          <div className="lg:col-span-5 relative">
            <InteractiveTilt maxTilt={6} scale={1.02}>
              <div className="relative rounded-3xl overflow-hidden p-2.5 bg-gradient-to-b from-[#FFFFFF] to-[#EAE4D9] shadow-2xl border border-[#E3D9CC]">
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-[#20201D]">
                  <img
                    src="/images/salon-interior.jpg"
                    alt="Stylopia Hair Studio interior in Sitabuldi, Nagpur"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#141413]/70 via-transparent to-transparent pointer-events-none" />

                  <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl glass-card-dark text-[#FAF8F5]">
                    <p className="text-[10px] uppercase tracking-widest text-[#C5A059] font-semibold">
                      The Sanctuary
                    </p>
                    <p className="font-serif text-base text-white">
                      Modern Minimalist Studio Experience
                    </p>
                    <p className="text-xs text-[#A8A49C]">
                      Jhansi Rani Square, Sitabuldi
                    </p>
                  </div>
                </div>
              </div>
            </InteractiveTilt>

            {/* Floating Women-Owned Badge */}
            <div className="absolute -bottom-6 -left-4 sm:-left-6 glass-card p-4 rounded-2xl shadow-xl border border-white flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#141413] flex items-center justify-center text-[#C5A059]">
                <Heart className="w-5 h-5 fill-[#C5A059]" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-widest text-[#736F68] font-bold block">
                  Studio Identity
                </span>
                <span className="text-xs font-bold text-[#141413]">
                  {BUSINESS_INFO.businessAttribute}
                </span>
              </div>
            </div>
          </div>

          {/* Right Text Column: Brand Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-[0.2em] font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              About Stylopia
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-[#141413] tracking-tight leading-tight">
              A Warm Sanctuary For Personal Style & Hair Wellness
            </h2>

            <div className="space-y-4 text-sm sm:text-base text-[#5A5751] font-light leading-relaxed">
              <p>
                At <strong>Stylopia Hair Studio</strong>, we believe every crown of hair has its own unique story, texture, and natural movement. Located in the bustling heart of Sitabuldi, Nagpur, our studio was created to offer a serene, refined sanctuary where you can pause, unwind, and invest in thoughtful hair self-care.
              </p>
              <p>
                Whether you are seeking a face-framing precision haircut, sun-drenched caramel balayage, or restorative moisture therapy for humidity-stressed strands, our focus remains squarely on your personal style and enduring hair health. We prioritize attentive consultations, ensuring every ritual aligns seamlessly with your everyday lifestyle.
              </p>
            </div>

            {/* Verified Salon Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#EAE3D8] space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-[#141413] font-semibold text-sm">
                  <Star className="w-4 h-4 text-[#C5A059] fill-[#C5A059]" />
                  <span>4.7 Star Rating · 513 Reviews</span>
                </div>
                <p className="text-xs text-[#736F68]">
                  Consistently trusted by women across Nagpur for mindful haircare and genuine service.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#EAE3D8] space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-[#141413] font-semibold text-sm">
                  <Clock className="w-4 h-4 text-[#C5A059]" />
                  <span>Open Daily Until 10 PM</span>
                </div>
                <p className="text-xs text-[#736F68]">
                  Flexible late-evening hours accommodating working professionals and bridal schedules.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#EAE3D8] space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-[#141413] font-semibold text-sm">
                  <MapPin className="w-4 h-4 text-[#C5A059]" />
                  <span>Central Nagpur Location</span>
                </div>
                <p className="text-xs text-[#736F68]">
                  Located at Jhansi Rani Square, behind Nilawar Sadi Center, Sitabuldi.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#EAE3D8] space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-[#141413] font-semibold text-sm">
                  <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
                  <span>Women-Owned Haircraft</span>
                </div>
                <p className="text-xs text-[#736F68]">
                  A welcoming, safe, and empowering environment built with genuine passion for hair wellness.
                </p>
              </div>
            </div>

            {/* Studio Note */}
            <div className="pt-2 text-xs text-[#8E8B82] italic">
              * Stylopia Hair Studio welcomes both advance reservations and walk-ins. We recommend booking in advance for weekend transformations and bridal styling.
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
