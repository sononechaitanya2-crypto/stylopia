import React, { useState, useRef, useCallback } from 'react';
import { Sparkles, MoveHorizontal } from 'lucide-react';

interface BeforeAfterSliderProps {
  onOpenBooking: () => void;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({ onOpenBooking }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(5, Math.min(95, (x / rect.width) * 100));
    setSliderPosition(percentage);
  }, []);

  const handleTouchMove = (e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current && e.buttons !== 1) return;
    handleMove(e.clientX);
  };

  return (
    <section className="py-20 bg-[#FAF8F5] relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-widest font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            Interactive Hair Transformation
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-normal text-[#141413]">
            Witness The Stylopia Glass Hair Finish
          </h2>
          <p className="text-xs sm:text-sm text-[#6B6862]">
            Drag the slider to preview the difference between untreated humidity-stressed strands and our signature Keratin Smoothening & Gloss finish.
          </p>
        </div>

        {/* Interactive Comparison Container */}
        <div className="relative max-w-4xl mx-auto rounded-3xl overflow-hidden shadow-2xl border-4 border-[#FFFFFF] select-none">
          <div
            ref={containerRef}
            onMouseDown={() => { isDragging.current = true; }}
            onMouseUp={() => { isDragging.current = false; }}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            className="relative w-full aspect-[16/10] sm:aspect-[16/9] cursor-ew-resize overflow-hidden bg-[#141413]"
          >
            {/* "After" Image (Full Width Underneath) */}
            <img
              src="/images/service-keratin.jpg"
              alt="After: Glossy mirror-like hair after Stylopia treatment"
              className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none"
            />
            
            {/* After Label */}
            <div className="absolute top-4 right-4 z-20 px-3.5 py-1.5 rounded-full bg-[#141413]/80 backdrop-blur-md text-[#FAF8F5] text-xs font-semibold uppercase tracking-wider border border-white/20">
              After: Keratin Glass Shine
            </div>

            {/* "Before" Image (Clipped on Left Side) */}
            <div
              className="absolute inset-y-0 left-0 overflow-hidden pointer-events-none"
              style={{ width: `${sliderPosition}%` }}
            >
              <img
                src="/images/service-haircut.jpg"
                alt="Before: Unstyled hair prior to salon treatment"
                className="absolute inset-0 w-full h-full object-cover object-center max-w-none"
                style={{
                  width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%',
                }}
              />
              {/* Before Label */}
              <div className="absolute top-4 left-4 z-20 px-3.5 py-1.5 rounded-full bg-[#FFFFFF]/90 backdrop-blur-md text-[#141413] text-xs font-semibold uppercase tracking-wider shadow-sm">
                Before: Untreated Texture
              </div>
            </div>

            {/* Draggable Divider Handle */}
            <div
              className="absolute inset-y-0 z-30 w-1 bg-[#FFFFFF] shadow-[0_0_15px_rgba(0,0,0,0.5)] cursor-ew-resize"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-[#141413] text-[#FAF8F5] border-2 border-[#FFFFFF] shadow-xl flex items-center justify-center hover:scale-110 transition-transform">
                <MoveHorizontal className="w-5 h-5 text-[#C5A059]" />
              </div>
            </div>
          </div>

          {/* Bottom Bar with CTA */}
          <div className="bg-[#141413] p-4 sm:p-5 text-[#FAF8F5] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <p className="font-serif text-lg font-medium text-[#FAF8F5]">Ready for your own hair revival?</p>
              <p className="text-xs text-[#A8A49C]">Customized for frizz control, high shine, and effortless daily styling.</p>
            </div>
            <button
              onClick={onOpenBooking}
              className="px-6 py-2.5 rounded-full bg-[#C5A059] text-[#141413] text-xs font-bold uppercase tracking-wider hover:bg-[#D4AF37] transition-all"
            >
              Book Transformation
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
