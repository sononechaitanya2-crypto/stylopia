import React, { useState, useEffect } from 'react';
import { Phone, Clock, Menu, X, Sparkles, MapPin } from 'lucide-react';
import { BUSINESS_INFO } from '../data/salonData';

interface NavbarProps {
  onOpenBooking: (serviceId?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Services', href: '#services' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'About', href: '#about' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* Top Announcement Bar */}
      <div className="bg-[#141413] text-[#EAE4D9] text-xs py-2 px-4 border-b border-[#2E2E2C]/50 transition-colors">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2 text-[11px] sm:text-xs">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-[#C5A059] font-medium tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] animate-pulse" />
              {BUSINESS_INFO.hours}
            </span>
            <span className="hidden sm:inline-block text-[#8E8B82]">|</span>
            <span className="hidden sm:flex items-center gap-1 text-[#C7C3BA]">
              <MapPin className="w-3 h-3 text-[#C5A059]" />
              {BUSINESS_INFO.shortAddress}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-[#C5A059] font-medium flex items-center gap-1">
              <span>★</span> {BUSINESS_INFO.rating} ({BUSINESS_INFO.reviewCount} Reviews)
            </span>
            <span className="text-[#8E8B82]">|</span>
            <a
              href={`tel:${BUSINESS_INFO.phoneRaw}`}
              className="hover:text-[#C5A059] transition-colors flex items-center gap-1 font-medium"
            >
              <Phone className="w-3 h-3 text-[#C5A059]" />
              {BUSINESS_INFO.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main Glassmorphic Sticky Header */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'glass-nav py-3.5 shadow-sm'
            : 'bg-[#FAF8F5]/90 backdrop-blur-md py-5 border-b border-[#EAE3D8]/60'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo */}
          <a href="#" className="group flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#141413] flex items-center justify-center text-[#C5A059] border border-[#C5A059]/40 group-hover:scale-105 transition-transform duration-300 shadow-sm">
              <span className="font-serif text-lg font-semibold tracking-tighter">S</span>
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#141413] group-hover:text-[#C5A059] transition-colors">
                Stylopia
              </span>
              <span className="text-[10px] tracking-[0.25em] uppercase text-[#6B6862] -mt-1 font-medium">
                Hair Studio · Nagpur
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium tracking-wide text-[#33312E] hover:text-[#C5A059] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1.5px] after:bg-[#C5A059] hover:after:w-full after:transition-all after:duration-300"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Action Button */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href={`tel:${BUSINESS_INFO.phoneRaw}`}
              className="p-2.5 rounded-full text-[#33312E] hover:text-[#C5A059] hover:bg-[#F3EFEA] transition-colors border border-transparent hover:border-[#EAE3D8]"
              title={`Call ${BUSINESS_INFO.phone}`}
            >
              <Phone className="w-4 h-4" />
            </a>

            <button
              onClick={() => onOpenBooking()}
              className="group relative inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#141413] text-[#FAF8F5] text-xs font-semibold tracking-wider uppercase overflow-hidden border border-[#141413] hover:border-[#C5A059] transition-all duration-300 shadow-sm hover:shadow-md"
            >
              <span className="relative z-10 flex items-center gap-1.5 group-hover:text-[#F7E7CE] transition-colors">
                <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                Book Appointment
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-[#C5A059] to-[#D4AF37] opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => onOpenBooking()}
              className="px-3.5 py-1.5 rounded-full bg-[#141413] text-[#FAF8F5] text-[11px] font-semibold tracking-wider uppercase"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#141413] hover:bg-[#F3EFEA] transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden glass-nav border-t border-[#EAE3D8] px-6 py-6 animate-fadeIn">
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-base font-medium text-[#141413] hover:text-[#C5A059] py-1 border-b border-[#EAE3D8]/40"
                >
                  {link.label}
                </a>
              ))}

              <div className="pt-4 flex flex-col gap-3">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenBooking();
                  }}
                  className="w-full py-3 rounded-full bg-[#141413] text-[#FAF8F5] text-center text-sm font-semibold tracking-wider uppercase flex items-center justify-center gap-2 shadow-md"
                >
                  <Sparkles className="w-4 h-4 text-[#C5A059]" />
                  Book an Appointment
                </button>
                <a
                  href={`tel:${BUSINESS_INFO.phoneRaw}`}
                  className="w-full py-2.5 rounded-full border border-[#141413]/20 text-[#141413] text-center text-sm font-medium flex items-center justify-center gap-2 hover:bg-[#F3EFEA]"
                >
                  <Phone className="w-4 h-4 text-[#C5A059]" />
                  Call {BUSINESS_INFO.phone}
                </a>
              </div>

              <div className="pt-2 text-xs text-[#6B6862] flex flex-col gap-1">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Jhansi Rani Square, Sitabuldi, Nagpur</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>{BUSINESS_INFO.hours}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
