import React, { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, CheckCircle, ExternalLink } from 'lucide-react';
import { BUSINESS_INFO, REVIEWS_DATA } from '../data/salonData';

export const ReviewsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevReview = () => {
    setCurrentIndex((prev) => (prev === 0 ? REVIEWS_DATA.length - 1 : prev - 1));
  };

  const nextReview = () => {
    setCurrentIndex((prev) => (prev === REVIEWS_DATA.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="reviews" className="py-24 bg-[#F5F2EB] relative overflow-hidden border-t border-[#EAE3D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-[0.2em] font-semibold">
            <Star className="w-3.5 h-3.5 fill-[#C5A059]" />
            Verified Client Praise
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-[#141413] tracking-tight">
            Loved By Women Across Nagpur
          </h2>

          <p className="text-sm sm:text-base text-[#6B6862] leading-relaxed">
            Authentic experiences from clients who entrusted their hair transformations, cuts, and restorative rituals to Stylopia Hair Studio.
          </p>
        </div>

        {/* Rating Overview Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-16">
          
          {/* Rating Summary Card */}
          <div className="lg:col-span-5 bg-[#FFFFFF] rounded-3xl p-8 sm:p-10 border border-[#EAE3D8] shadow-sm flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-widest text-[#7A756D] font-bold">
                  Overall Rating
                </span>
                <span className="px-3 py-1 rounded-full bg-[#FAF8F5] border border-[#EAE3D8] text-[11px] font-semibold text-[#141413] flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  Verified Business
                </span>
              </div>

              {/* Big 4.7 Rating */}
              <div className="flex items-baseline gap-4">
                <span className="font-serif text-6xl sm:text-7xl font-bold text-[#141413] tracking-tight">
                  {BUSINESS_INFO.rating}
                </span>
                <div>
                  <div className="flex text-[#C5A059] gap-1 mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-[#C5A059]" />
                    ))}
                  </div>
                  <p className="text-sm font-semibold text-[#141413]">
                    {BUSINESS_INFO.reviewCount} Total Reviews
                  </p>
                  <p className="text-xs text-[#8E8B82]">Sitabuldi, Nagpur</p>
                </div>
              </div>

              {/* Visual Breakdown */}
              <div className="space-y-2.5 pt-4 border-t border-[#F5F2EB]">
                {[
                  { stars: '5 Star', pct: '88%' },
                  { stars: '4 Star', pct: '9%' },
                  { stars: '3 Star', pct: '2%' },
                  { stars: '2 Star', pct: '1%' },
                  { stars: '1 Star', pct: '<1%' },
                ].map((row, i) => (
                  <div key={i} className="flex items-center gap-3 text-xs text-[#7A756D]">
                    <span className="w-12 font-medium">{row.stars}</span>
                    <div className="flex-1 h-2 bg-[#F3EFEA] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#C5A059] rounded-full"
                        style={{ width: row.pct }}
                      />
                    </div>
                    <span className="w-8 text-right font-medium">{row.pct}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-[#F5F2EB]">
              <a
                href={BUSINESS_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 w-full py-3 rounded-full bg-[#FAF8F5] hover:bg-[#141413] text-[#141413] hover:text-[#FAF8F5] border border-[#EAE3D8] text-xs font-semibold uppercase tracking-wider transition-all duration-300"
              >
                <span>View Google Maps Listing</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Testimonial Carousel Card */}
          <div className="lg:col-span-7 bg-[#FFFFFF] rounded-3xl p-8 sm:p-10 border border-[#EAE3D8] shadow-sm flex flex-col justify-between relative">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#F5F2EB]">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-[#141413] text-[#FAF8F5] font-serif text-base font-semibold flex items-center justify-center">
                    {REVIEWS_DATA[currentIndex].initials}
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#141413] text-base">
                      {REVIEWS_DATA[currentIndex].author}
                    </h4>
                    <p className="text-xs text-[#7A756D] flex items-center gap-1.5">
                      <span className="text-[#C5A059] font-medium">{REVIEWS_DATA[currentIndex].service}</span>
                      <span>·</span>
                      <span>{REVIEWS_DATA[currentIndex].date}</span>
                    </p>
                  </div>
                </div>

                <div className="flex text-[#C5A059] gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#C5A059]" />
                  ))}
                </div>
              </div>

              {/* Quote Content */}
              <div className="py-8">
                <p className="font-serif text-xl sm:text-2xl text-[#141413] italic font-normal leading-relaxed">
                  “{REVIEWS_DATA[currentIndex].comment}”
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs text-[#524F49]">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span className="font-medium">Verified Salon Experience</span>
              </div>
            </div>

            {/* Navigation Controls */}
            <div className="flex items-center justify-between pt-6 mt-6 border-t border-[#F5F2EB]">
              <div className="flex items-center gap-1.5">
                {REVIEWS_DATA.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentIndex(i)}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      currentIndex === i ? 'w-8 bg-[#141413]' : 'w-2 bg-[#EAE3D8]'
                    }`}
                    aria-label={`Go to review ${i + 1}`}
                  />
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={prevReview}
                  className="w-10 h-10 rounded-full border border-[#EAE3D8] hover:border-[#141413] flex items-center justify-center text-[#141413] hover:bg-[#141413] hover:text-[#FAF8F5] transition-colors"
                  aria-label="Previous review"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={nextReview}
                  className="w-10 h-10 rounded-full border border-[#EAE3D8] hover:border-[#141413] flex items-center justify-center text-[#141413] hover:bg-[#141413] hover:text-[#FAF8F5] transition-colors"
                  aria-label="Next review"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* Transparent Compliance Note */}
        <p className="text-center text-xs text-[#8E8B82] max-w-xl mx-auto italic">
          * Reviews shown above represent editable client testimonial highlights and sample experiences. Overall rating of 4.7 stars across 513 reviews reflects the salon's publicly listed Google rating.
        </p>

      </div>
    </section>
  );
};
