import React from 'react';
import { Phone, Sparkles } from 'lucide-react';
import { BUSINESS_INFO } from '../data/salonData';

interface QuickContactBarProps {
  onOpenBooking: () => void;
}

export const QuickContactBar: React.FC<QuickContactBarProps> = ({ onOpenBooking }) => {
  return (
    <div className="fixed bottom-4 left-4 right-4 z-30 md:hidden animate-fadeIn">
      <div className="bg-[#141413]/95 backdrop-blur-xl border border-[#C5A059]/40 p-2 rounded-2xl shadow-2xl flex items-center justify-between gap-2">
        <a
          href={`tel:${BUSINESS_INFO.phoneRaw}`}
          className="flex-1 py-2.5 px-3 rounded-xl bg-[#262623] text-[#FAF8F5] text-xs font-semibold flex items-center justify-center gap-1.5 border border-white/10"
        >
          <Phone className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Call Salon</span>
        </a>

        <button
          onClick={onOpenBooking}
          className="flex-1 py-2.5 px-3 rounded-xl bg-[#C5A059] text-[#141413] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Book Chair</span>
        </button>
      </div>
    </div>
  );
};
