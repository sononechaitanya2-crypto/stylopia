import React, { useState, useEffect } from 'react';
import { GALLERY_ITEMS } from '../data/salonData';
import { GalleryItem } from '../types';
import { Sparkles, Maximize2, X, ChevronLeft, ChevronRight, Check } from 'lucide-react';

interface GallerySectionProps {
  onBookLook: (lookTitle: string) => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ onBookLook }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedItemIndex, setSelectedItemIndex] = useState<number | null>(null);

  const categories = [
    { id: 'all', label: 'All Looks' },
    { id: 'transformations', label: 'Transformations' },
    { id: 'colour', label: 'Hair Colour & Balayage' },
    { id: 'bridal', label: 'Bridal & Party' },
    { id: 'cuts', label: 'Precision Cuts' },
    { id: 'studio', label: 'Studio Interior' },
  ];

  const filteredItems = GALLERY_ITEMS.filter((item) => {
    if (activeCategory === 'all') return true;
    return item.category === activeCategory;
  });

  const selectedItem: GalleryItem | null =
    selectedItemIndex !== null ? filteredItems[selectedItemIndex] : null;

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedItemIndex === null) return;
      if (e.key === 'Escape') setSelectedItemIndex(null);
      if (e.key === 'ArrowRight') {
        setSelectedItemIndex((prev) =>
          prev !== null ? (prev + 1) % filteredItems.length : null
        );
      }
      if (e.key === 'ArrowLeft') {
        setSelectedItemIndex((prev) =>
          prev !== null ? (prev - 1 + filteredItems.length) % filteredItems.length : null
        );
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedItemIndex, filteredItems.length]);

  return (
    <section id="gallery" className="py-24 bg-[#FAF8F5] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-[0.2em] font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            Editorial Lookbook
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-[#141413] tracking-tight">
            Hair Craftsmanship & Salon Aesthetics
          </h2>

          <p className="text-sm sm:text-base text-[#6B6862] leading-relaxed">
            A curated portfolio of gloss transformations, caramel balayage, and wedding artistry photographed in authentic studio lighting.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveCategory(cat.id);
                  setSelectedItemIndex(null);
                }}
                className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-300 ${
                  activeCategory === cat.id
                    ? 'bg-[#141413] text-[#FAF8F5] shadow-sm'
                    : 'bg-[#FFFFFF] text-[#6B6862] hover:text-[#141413] border border-[#EAE3D8]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Asymmetrical Masonry Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              onClick={() => setSelectedItemIndex(index)}
              className="group relative cursor-pointer rounded-2xl overflow-hidden bg-[#20201D] shadow-sm hover:shadow-2xl transition-all duration-500 border border-[#EAE3D8]/80"
              style={{
                aspectRatio: item.aspect === 'wide' ? '16/10' : '4/5',
              }}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-108"
                loading="lazy"
              />

              {/* Hover Overlay with 3D Depth */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#141413]/90 via-[#141413]/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-6 flex flex-col justify-between">
                
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#FAF8F5]/90 text-[#141413] backdrop-blur-sm">
                    {item.categoryLabel}
                  </span>
                  <div className="w-9 h-9 rounded-full bg-[#141413]/80 text-[#FAF8F5] border border-white/20 flex items-center justify-center group-hover:rotate-90 transition-transform duration-300">
                    <Maximize2 className="w-4 h-4 text-[#C5A059]" />
                  </div>
                </div>

                <div className="space-y-1 transform translate-y-3 group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="font-serif text-xl font-semibold text-[#FAF8F5]">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#D8CBBF] line-clamp-2">
                    {item.description}
                  </p>
                  <span className="inline-block text-[11px] font-bold text-[#E0C58A] pt-1">
                    Click to view full look →
                  </span>
                </div>

              </div>

            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {selectedItem && (
          <div
            className="fixed inset-0 z-50 bg-[#141413]/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-fadeIn"
            onClick={() => setSelectedItemIndex(null)}
          >
            <div
              className="relative max-w-4xl w-full bg-[#1C1C1A] text-[#FAF8F5] rounded-3xl overflow-hidden shadow-2xl border border-[#C5A059]/30 flex flex-col md:flex-row max-h-[90vh]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedItemIndex(null)}
                className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-[#141413]/80 hover:bg-[#C5A059] text-white hover:text-[#141413] flex items-center justify-center transition-colors"
                aria-label="Close Lightbox"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Prev / Next Arrows */}
              <button
                onClick={() =>
                  setSelectedItemIndex(
                    (selectedItemIndex! - 1 + filteredItems.length) % filteredItems.length
                  )
                }
                className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-[#141413]/80 text-white hover:bg-[#C5A059] hover:text-[#141413] flex items-center justify-center transition-colors"
                aria-label="Previous Look"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              <button
                onClick={() =>
                  setSelectedItemIndex((selectedItemIndex! + 1) % filteredItems.length)
                }
                className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-[#141413]/80 text-white hover:bg-[#C5A059] hover:text-[#141413] flex items-center justify-center transition-colors md:right-auto md:left-[55%]"
                aria-label="Next Look"
              >
                <ChevronRight className="w-6 h-6" />
              </button>

              {/* Large Image Preview */}
              <div className="md:w-3/5 bg-black flex items-center justify-center overflow-hidden">
                <img
                  src={selectedItem.image}
                  alt={selectedItem.title}
                  className="w-full h-full max-h-[75vh] object-cover md:object-contain"
                />
              </div>

              {/* Details & Action Panel */}
              <div className="md:w-2/5 p-6 sm:p-8 flex flex-col justify-between space-y-6 overflow-y-auto">
                <div className="space-y-4">
                  <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-[#C5A059]/20 text-[#E0C58A] border border-[#C5A059]/30">
                    {selectedItem.categoryLabel}
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl font-normal text-white">
                    {selectedItem.title}
                  </h3>

                  <p className="text-sm text-[#A8A49C] leading-relaxed">
                    {selectedItem.description}
                  </p>

                  <div className="pt-2 border-t border-white/10 space-y-2 text-xs text-[#D8CBBF]">
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#C5A059]" />
                      <span>Customized to your facial structure & texture</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#C5A059]" />
                      <span>Crafted at Stylopia Hair Studio, Nagpur</span>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-white/10">
                  <button
                    onClick={() => {
                      setSelectedItemIndex(null);
                      onBookLook(selectedItem.title);
                    }}
                    className="w-full py-3.5 rounded-full bg-[#C5A059] hover:bg-[#D4AF37] text-[#141413] text-xs font-bold uppercase tracking-wider transition-colors shadow-lg"
                  >
                    Book This Signature Look
                  </button>
                  <p className="text-center text-[11px] text-[#7A756D] mt-2">
                    Direct confirmation · Sitabuldi, Nagpur
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
