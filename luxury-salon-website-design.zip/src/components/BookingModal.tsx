import React, { useState, useEffect } from 'react';
import { X, Sparkles, Phone, Check, Calendar, User, Heart } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BUSINESS_INFO, SERVICES } from '../data/salonData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedService?: string | null;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  preSelectedService,
}) => {
  const [selectedService, setSelectedService] = useState<string>('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('11:00 AM');
  const [stylistPref, setStylistPref] = useState('Any Senior Stylist');
  const [notes, setNotes] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (preSelectedService) {
      setSelectedService(preSelectedService);
    } else if (SERVICES.length > 0 && !selectedService) {
      setSelectedService(SERVICES[0].title);
    }
  }, [preSelectedService, isOpen, selectedService]);

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#C5A059', '#141413', '#E0C58A', '#F5F2EB'],
    });

    setIsSuccess(true);
  };

  const handleResetAndClose = () => {
    setIsSuccess(false);
    onClose();
  };

  const availableSlots = [
    '10:30 AM',
    '11:30 AM',
    '01:00 PM',
    '02:30 PM',
    '04:00 PM',
    '05:30 PM',
    '07:00 PM',
    '08:30 PM',
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-[#141413]/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={handleResetAndClose}
    >
      <div
        className="relative max-w-xl w-full bg-[#FFFFFF] rounded-3xl overflow-hidden shadow-2xl border border-[#EAE3D8] my-8 animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon */}
        <div className="bg-[#141413] text-[#FAF8F5] p-6 sm:p-7 relative">
          <button
            onClick={handleResetAndClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#C5A059]/20 text-[#E0C58A] text-[11px] uppercase tracking-widest font-semibold border border-[#C5A059]/30 mb-2">
            <Sparkles className="w-3 h-3 text-[#C5A059]" />
            Stylopia Reservation
          </div>

          <h3 className="font-serif text-2xl sm:text-3xl font-normal text-white">
            Schedule Your Salon Visit
          </h3>
          <p className="text-xs text-[#A8A49C] mt-1">
            Sitabuldi, Nagpur · Open daily until 10:00 PM
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8">
          {isSuccess ? (
            <div className="text-center py-6 space-y-6">
              <div className="w-16 h-16 rounded-full bg-[#F5F2EB] text-[#C5A059] border-2 border-[#C5A059] flex items-center justify-center mx-auto shadow-sm">
                <Check className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <h4 className="font-serif text-2xl font-semibold text-[#141413]">
                  Appointment Request Confirmed!
                </h4>
                <p className="text-xs sm:text-sm text-[#6B6862] max-w-md mx-auto">
                  We look forward to welcoming you, <strong>{name}</strong>! Your request for{' '}
                  <strong>{selectedService}</strong> on{' '}
                  <strong>{date || 'Upcoming Date'}</strong> at <strong>{timeSlot}</strong> has been received.
                </p>
              </div>

              {/* Salon Summary Card */}
              <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D8] text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between text-[#141413]">
                  <span className="text-[#736F68]">Salon:</span>
                  <span className="font-semibold">{BUSINESS_INFO.name}</span>
                </div>
                <div className="flex justify-between text-[#141413]">
                  <span className="text-[#736F68]">Location:</span>
                  <span className="font-medium">Jhansi Rani Sq, Sitabuldi</span>
                </div>
                <div className="flex justify-between text-[#141413]">
                  <span className="text-[#736F68]">Stylist:</span>
                  <span className="font-medium">{stylistPref}</span>
                </div>
                <div className="flex justify-between text-[#141413]">
                  <span className="text-[#736F68]">Salon Contact:</span>
                  <span className="font-bold text-[#8C6D28]">{BUSINESS_INFO.phone}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <a
                  href={`tel:${BUSINESS_INFO.phoneRaw}`}
                  className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#141413] text-[#FAF8F5] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-[#C5A059] transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call {BUSINESS_INFO.phone} to Confirm</span>
                </a>
                <button
                  onClick={handleResetAndClose}
                  className="w-full sm:w-auto px-6 py-3 rounded-full border border-[#D9D1C5] text-[#141413] text-xs font-semibold uppercase tracking-wider hover:bg-[#FAF8F5]"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Service Selection */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1">
                  Selected Hair Ritual
                </label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                >
                  {SERVICES.map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title} ({s.startingPrice})
                    </option>
                  ))}
                </select>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1">
                    Your Name *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      placeholder="e.g. Priyadarshini"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                    />
                    <User className="w-4 h-4 text-[#8E8B82] absolute left-3 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1">
                    Contact Phone *
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 092265 39619"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                    />
                    <Phone className="w-4 h-4 text-[#8E8B82] absolute left-3 top-3" />
                  </div>
                </div>
              </div>

              {/* Date & Time Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1">
                    Preferred Date
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                    />
                    <Calendar className="w-4 h-4 text-[#8E8B82] absolute left-3 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1">
                    Stylist Preference
                  </label>
                  <select
                    value={stylistPref}
                    onChange={(e) => setStylistPref(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                  >
                    <option value="Any Senior Stylist">Any Senior Stylist</option>
                    <option value="Balayage & Colour Specialist">Balayage Specialist</option>
                    <option value="Texture & Keratin Expert">Texture Expert</option>
                    <option value="Bridal Styling Specialist">Bridal Specialist</option>
                  </select>
                </div>
              </div>

              {/* Quick Time Slot Chips */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5 flex items-center justify-between">
                  <span>Available Time Slot</span>
                  <span className="text-[11px] text-[#8E8B82] normal-case">Hours: 10 AM – 10 PM</span>
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {availableSlots.map((slot) => (
                    <button
                      type="button"
                      key={slot}
                      onClick={() => setTimeSlot(slot)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-medium border text-center transition-all ${
                        timeSlot === slot
                          ? 'bg-[#141413] text-[#FAF8F5] border-[#141413]'
                          : 'bg-[#FAF8F5] text-[#55524C] border-[#EAE3D8] hover:border-[#C5A059]'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Optional Notes */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1">
                  Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. First time coloring, want subtle face frame..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-xs text-[#141413] focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-full bg-[#141413] hover:bg-[#C5A059] text-[#FAF8F5] text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-md group"
                >
                  <Sparkles className="w-4 h-4 text-[#C5A059] group-hover:rotate-12 transition-transform" />
                  <span>Confirm Appointment Reservation</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[11px] text-[#7A756D] pt-1">
                <Heart className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>{BUSINESS_INFO.businessAttribute} · Sitabuldi, Nagpur</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
