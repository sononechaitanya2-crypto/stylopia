import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Clock,
  Heart,
  Copy,
  Check,
  Send,
  Sparkles,
  ExternalLink,
  Calendar,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { BUSINESS_INFO, SERVICES } from '../data/salonData';

export const ContactSection: React.FC = () => {
  const [copiedPlusCode, setCopiedPlusCode] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: 'Haircuts & Precision Styling',
    date: '',
    timeSlot: 'Morning (10:00 AM – 1:00 PM)',
    notes: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleCopyPlusCode = () => {
    navigator.clipboard.writeText(BUSINESS_INFO.plusCode);
    setCopiedPlusCode(true);
    setTimeout(() => setCopiedPlusCode(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    // Trigger luxury celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.65 },
      colors: ['#C5A059', '#141413', '#E0C58A', '#F5F2EB'],
    });

    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-24 bg-[#FAF8F5] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-[0.2em] font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            Visit & Connect
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-[#141413] tracking-tight">
            Reserve Your Stylopia Experience
          </h2>

          <p className="text-sm sm:text-base text-[#6B6862] leading-relaxed">
            Conveniently located at Jhansi Rani Square in Sitabuldi, Nagpur. Call directly or submit an inquiry for bespoke appointments.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Exact Verified Business Details */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Primary Details Card */}
            <div className="bg-[#FFFFFF] p-7 sm:p-8 rounded-3xl border border-[#EAE3D8] shadow-sm space-y-6">
              <div className="border-b border-[#F5F2EB] pb-4">
                <span className="text-[10px] uppercase tracking-widest text-[#8E8B82] font-semibold block">
                  Category: {BUSINESS_INFO.category}
                </span>
                <h3 className="font-serif text-2xl font-semibold text-[#141413]">
                  {BUSINESS_INFO.name}
                </h3>
              </div>

              {/* Exact Address */}
              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-full bg-[#F5F2EB] flex items-center justify-center text-[#C5A059] shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-[#141413]">Salon Address</p>
                  <p className="text-xs sm:text-sm text-[#55524C] leading-relaxed">
                    {BUSINESS_INFO.address}
                  </p>
                  <a
                    href={BUSINESS_INFO.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#8C6D28] hover:text-[#141413] font-semibold pt-1 transition-colors"
                  >
                    <span>Get Directions on Google Maps</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Exact Google Maps Plus Code */}
              <div className="p-3.5 rounded-2xl bg-[#F8F5EE] border border-[#EAE3D8] flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase tracking-wider text-[#736F68] font-bold block">
                    Google Maps Plus Code
                  </span>
                  <span className="text-xs font-mono font-medium text-[#141413]">
                    {BUSINESS_INFO.plusCode}
                  </span>
                </div>
                <button
                  onClick={handleCopyPlusCode}
                  className="px-3 py-1.5 rounded-lg bg-[#FFFFFF] hover:bg-[#141413] text-[#141413] hover:text-[#FAF8F5] border border-[#EAE3D8] text-xs font-medium flex items-center gap-1.5 transition-colors"
                  title="Copy Plus Code to clipboard"
                >
                  {copiedPlusCode ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span className="text-[11px]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span className="text-[11px]">Copy</span>
                    </>
                  )}
                </button>
              </div>

              {/* Exact Phone */}
              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-full bg-[#F5F2EB] flex items-center justify-center text-[#C5A059] shrink-0 mt-0.5">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-[#141413]">Telephone Direct Line</p>
                  <a
                    href={`tel:${BUSINESS_INFO.phoneRaw}`}
                    className="font-serif text-xl sm:text-2xl font-bold text-[#141413] hover:text-[#C5A059] transition-colors block"
                  >
                    {BUSINESS_INFO.phone}
                  </a>
                  <p className="text-[11px] text-[#7A756D]">
                    Click above to call directly for instant booking confirmation
                  </p>
                </div>
              </div>

              {/* Hours & Business Attribute */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D8]">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#141413] mb-1">
                    <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>Listed Hours</span>
                  </div>
                  <p className="text-xs text-[#524F49] font-medium">{BUSINESS_INFO.hours}</p>
                  <p className="text-[10px] text-[#8E8B82]">10:00 AM – 10:00 PM</p>
                </div>

                <div className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D8]">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#141413] mb-1">
                    <Heart className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>Studio Attribute</span>
                  </div>
                  <p className="text-xs text-[#524F49] font-medium">
                    {BUSINESS_INFO.businessAttribute}
                  </p>
                  <p className="text-[10px] text-[#8E8B82]">Sitabuldi, Nagpur</p>
                </div>
              </div>

              {/* Instagram Exact Link */}
              <div className="pt-2">
                <a
                  href={BUSINESS_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-[#FAF8F5] hover:bg-[#141413] text-[#141413] hover:text-[#FAF8F5] border border-[#EAE3D8] text-xs font-semibold uppercase tracking-wider transition-all duration-300"
                >
                  <svg className="w-4 h-4 text-[#C5A059]" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                  <span>Follow on Instagram ({BUSINESS_INFO.instagramUrl.replace('https://', '')})</span>
                </a>
              </div>

            </div>

            {/* Embedded Google Map */}
            <div className="rounded-3xl overflow-hidden border border-[#EAE3D8] shadow-sm bg-[#FAF8F5] h-56 relative">
              <iframe
                title="Stylopia Hair Studio Nagpur Location Map"
                src="https://maps.google.com/maps?q=Jhansi%20Rani%20Square,%20Sitabuldi,%20Nagpur,%20Maharashtra&t=&z=15&ie=UTF8&iwloc=&output=embed"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                aria-hidden="false"
              />
              <div className="absolute bottom-2 left-2 right-2 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl text-[11px] text-[#141413] border border-black/10 flex items-center justify-between">
                <span>Behind Nilawar Sadi Center, Sitabuldi</span>
                <a
                  href={BUSINESS_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#8C6D28] font-bold hover:underline"
                >
                  Open Map ↗
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Minimal Appointment Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-[#FFFFFF] p-8 sm:p-10 rounded-3xl border border-[#EAE3D8] shadow-sm relative">
              
              <div className="space-y-2 mb-8">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-widest text-[#8C6D28] font-semibold">
                    Appointment Inquiry
                  </span>
                  <span className="text-xs text-[#7A756D] flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                    Response in ~15 mins
                  </span>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#141413]">
                  Book Your Chair at Stylopia
                </h3>
                <p className="text-xs sm:text-sm text-[#6B6862]">
                  Fill out your preferred service details below or call <strong>092265 39619</strong> directly.
                </p>
              </div>

              {submitted ? (
                <div className="p-8 rounded-2xl bg-[#F7F4EE] border border-[#C5A059]/40 text-center space-y-5 animate-fadeIn">
                  <div className="w-14 h-14 rounded-full bg-[#141413] text-[#C5A059] flex items-center justify-center mx-auto shadow-md">
                    <Check className="w-7 h-7" />
                  </div>
                  <div className="space-y-1.5">
                    <h4 className="font-serif text-2xl font-semibold text-[#141413]">
                      Inquiry Received With Pleasure
                    </h4>
                    <p className="text-xs sm:text-sm text-[#55524C] max-w-md mx-auto">
                      Thank you, <strong>{formData.name}</strong>! We have noted your request for <strong>{formData.service}</strong>. Our front desk team will contact you shortly at <strong>{formData.phone}</strong> to confirm your slot.
                    </p>
                  </div>

                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={`tel:${BUSINESS_INFO.phoneRaw}`}
                      className="px-6 py-2.5 rounded-full bg-[#141413] text-[#FAF8F5] text-xs font-semibold uppercase tracking-wider flex items-center gap-2 hover:bg-[#C5A059] transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call Now: {BUSINESS_INFO.phone}</span>
                    </a>
                    <button
                      onClick={() => setSubmitted(false)}
                      className="px-6 py-2.5 rounded-full border border-[#D9D1C5] text-[#141413] text-xs font-semibold uppercase tracking-wider hover:bg-white transition-colors"
                    >
                      Submit Another Request
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Radhika Sharma"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059] focus:ring-1 focus:ring-[#C5A059]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 098765 43210"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059] focus:ring-1 focus:ring-[#C5A059]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5">
                        Service Desired
                      </label>
                      <select
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                      >
                        {SERVICES.map((s) => (
                          <option key={s.id} value={s.title}>
                            {s.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5">
                        Preferred Date
                      </label>
                      <div className="relative">
                        <input
                          type="date"
                          value={formData.date}
                          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                        />
                        <Calendar className="w-4 h-4 text-[#8E8B82] absolute right-3.5 top-3.5 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5">
                      Preferred Time Slot
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {[
                        'Morning (10 AM – 1 PM)',
                        'Afternoon (1 PM – 5 PM)',
                        'Evening (5 PM – 9:30 PM)',
                      ].map((slot) => (
                        <button
                          type="button"
                          key={slot}
                          onClick={() => setFormData({ ...formData, timeSlot: slot })}
                          className={`py-2 px-3 rounded-xl text-xs font-medium border text-center transition-all ${
                            formData.timeSlot === slot
                              ? 'bg-[#141413] text-[#FAF8F5] border-[#141413]'
                              : 'bg-[#FAF8F5] text-[#55524C] border-[#EAE3D8] hover:border-[#C5A059]'
                          }`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#4A4742] mb-1.5">
                      Special Notes or Hair Texture Details (Optional)
                    </label>
                    <textarea
                      rows={3}
                      placeholder="e.g. Thick wavy hair, looking for warm caramel balayage without bleach damage..."
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#FAF8F5] border border-[#EAE3D8] text-sm text-[#141413] focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-full bg-[#141413] hover:bg-[#C5A059] text-[#FAF8F5] text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all duration-300 shadow-md group"
                  >
                    <span>Submit Appointment Request</span>
                    <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>

                  <p className="text-center text-[11px] text-[#7A756D]">
                    Prefer to speak right now? Call us directly at{' '}
                    <a
                      href={`tel:${BUSINESS_INFO.phoneRaw}`}
                      className="text-[#141413] font-bold underline hover:text-[#C5A059]"
                    >
                      {BUSINESS_INFO.phone}
                    </a>
                  </p>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
