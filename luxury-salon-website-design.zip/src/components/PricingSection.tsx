import React, { useState } from 'react';
import { PRICING_DATA } from '../data/salonData';
import { Sparkles, Info, Clock, ArrowRight } from 'lucide-react';

interface PricingSectionProps {
  onBookService: (serviceName: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onBookService }) => {
  const [activeTab, setActiveTab] = useState(0);

  const activeCategory = PRICING_DATA[activeTab];

  return (
    <section id="pricing" className="py-24 bg-[#FAF8F5] relative overflow-hidden border-t border-[#EAE3D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#EAE3D8] text-[#8C6D28] text-xs uppercase tracking-[0.2em] font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            Transparent Investment
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-[#141413] tracking-tight">
            Curated Salon Pricing
          </h2>

          <p className="text-sm sm:text-base text-[#6B6862] leading-relaxed">
            Every service is tailored with personalized attention and premium formulation. Choose your desired ritual below.
          </p>

          {/* Illustrative Notice Disclaimer */}
          <div className="inline-flex items-center gap-2 p-3 rounded-2xl bg-[#F4EFEB] border border-[#E3D9CC] text-left text-xs text-[#7A756D] max-w-2xl mt-2">
            <Info className="w-4 h-4 text-[#C5A059] shrink-0" />
            <span>
              <strong>Note on Pricing:</strong> Sample prices indicated below (*) are illustrative starting estimates. Actual investment is confirmed transparently by our senior stylists prior to service commencement based on hair density, length, and technical complexity.
            </span>
          </div>
        </div>

        {/* Category Navigation Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {PRICING_DATA.map((cat, index) => (
            <button
              key={cat.id}
              onClick={() => setActiveTab(index)}
              className={`px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-300 ${
                activeTab === index
                  ? 'bg-[#141413] text-[#FAF8F5] shadow-md scale-102'
                  : 'bg-[#FFFFFF] text-[#55524C] hover:text-[#141413] border border-[#EAE3D8] hover:border-[#141413]/30'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Active Category Description */}
        <p className="text-center text-xs text-[#8E8B82] mb-8 font-medium">
          {activeCategory.description}
        </p>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {activeCategory.items.map((item, idx) => (
            <div
              key={idx}
              className={`relative p-6 sm:p-7 rounded-2xl bg-[#FFFFFF] border transition-all duration-300 flex flex-col justify-between hover:shadow-lg ${
                item.popular
                  ? 'border-[#C5A059] shadow-md ring-1 ring-[#C5A059]/20'
                  : 'border-[#EAE3D8] hover:border-[#C5A059]/40'
              }`}
            >
              {item.popular && (
                <div className="absolute -top-3 right-6">
                  <span className="px-3 py-1 rounded-full bg-[#141413] text-[#E0C58A] text-[10px] font-bold uppercase tracking-wider border border-[#C5A059]/40 shadow-xs">
                    Client Favorite
                  </span>
                </div>
              )}

              <div className="space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#141413] leading-snug">
                    {item.name}
                  </h3>
                  <div className="text-right shrink-0">
                    <span className="font-serif text-xl sm:text-2xl font-bold text-[#141413]">
                      {item.price}
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-[#6B6862] leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-5 mt-4 border-t border-[#F5F2EB] flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-[#8E8B82]">
                  <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Est. {item.duration}</span>
                </div>

                <button
                  onClick={() => onBookService(item.name)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#141413] hover:bg-[#C5A059] text-[#FAF8F5] text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  <span>Book Now</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Custom Pricing Callout */}
        <div className="text-center mt-12 text-xs text-[#7A756D]">
          Planning a wedding group or corporate makeover in Nagpur?{' '}
          <a
            href="tel:09226539619"
            className="font-bold text-[#141413] hover:text-[#C5A059] underline underline-offset-4"
          >
            Call 092265 39619
          </a>{' '}
          for bespoke bridal package estimates.
        </div>

      </div>
    </section>
  );
};
