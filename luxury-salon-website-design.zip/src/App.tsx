import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { PricingSection } from './components/PricingSection';
import { GallerySection } from './components/GallerySection';
import { AboutSection } from './components/AboutSection';
import { ReviewsSection } from './components/ReviewsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { QuickContactBar } from './components/QuickContactBar';
import { ServiceItem } from './types';

export function App() {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedServiceName, setSelectedServiceName] = useState<string | null>(null);

  const handleOpenBooking = (serviceName?: string) => {
    setSelectedServiceName(serviceName || null);
    setBookingModalOpen(true);
  };

  const handleSelectService = (service: ServiceItem) => {
    handleOpenBooking(service.title);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#141413] selection:bg-[#C5A059] selection:text-white">
      {/* Sticky Navigation */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      {/* Main Content */}
      <main>
        {/* Full Screen Cinematic Hero */}
        <Hero onOpenBooking={() => handleOpenBooking()} />

        {/* Curated Hair Services Menu */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* Interactive Before & After Transformation Slider */}
        <BeforeAfterSlider onOpenBooking={() => handleOpenBooking('Keratin & Smoothening')} />

        {/* Minimal Luxury Pricing */}
        <PricingSection onBookService={(serviceName) => handleOpenBooking(serviceName)} />

        {/* Editorial Hair Lookbook & Gallery with Lightbox */}
        <GallerySection onBookLook={(lookTitle) => handleOpenBooking(`Look: ${lookTitle}`)} />

        {/* About Stylopia Hair Studio */}
        <AboutSection />

        {/* Verified 4.7 Stars / 513 Reviews Testimonials */}
        <ReviewsSection />

        {/* Verified Contact Details, Map & Appointment Form */}
        <ContactSection />
      </main>

      {/* Minimal Footer */}
      <Footer />

      {/* Mobile Floating Action Bar */}
      <QuickContactBar onOpenBooking={() => handleOpenBooking()} />

      {/* Luxury Appointment Booking Dialog */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        preSelectedService={selectedServiceName}
      />
    </div>
  );
}

export default App;
