export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  tagline: string;
  description: string;
  duration: string;
  startingPrice: string;
  image: string;
  benefits: string[];
  popular?: boolean;
}

export interface PricingCategory {
  id: string;
  name: string;
  description: string;
  items: {
    name: string;
    description: string;
    price: string;
    duration: string;
    popular?: boolean;
  }[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'transformations' | 'colour' | 'bridal' | 'cuts' | 'studio';
  categoryLabel: string;
  image: string;
  description: string;
  aspect?: 'tall' | 'wide' | 'square';
}

export interface ReviewItem {
  id: string;
  author: string;
  rating: number;
  date: string;
  service: string;
  comment: string;
  verified: boolean;
  initials: string;
}

export interface AppointmentData {
  fullName: string;
  phone: string;
  email: string;
  service: string;
  preferredDate: string;
  preferredTime: string;
  stylistPreference: string;
  notes: string;
}
